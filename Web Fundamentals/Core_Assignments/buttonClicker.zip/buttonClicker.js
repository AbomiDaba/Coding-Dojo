function logout(element){
    element.innerText= "logout";
}
function hide(element){
    element.remove();
}
function notice(){
    alert('Ninja was liked');
}