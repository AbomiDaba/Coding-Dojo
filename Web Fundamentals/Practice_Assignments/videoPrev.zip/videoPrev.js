console.log("page loaded...");

function playVid(element) {
    element.play();
}

function pauseVid(element) {
    element.pause();
}